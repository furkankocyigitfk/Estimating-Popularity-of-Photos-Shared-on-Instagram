package com.example.thepredictorv1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private Button loginButton;
    private Button testButton;
    private EditText usernameEditText;
    private String urlJsonArry;
    private User user;
    private List<User> userList;
    private  static int iter = 0;

    double number_followees;
    double number_followers;
    double number_highlights;
    double number_media;
    double is_business;
    double is_professional;
    double is_verified;
    String biography;

    public static ModelLike modelLike = new ModelLike();
    public static ModelComment modelComment = new ModelComment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        loginButton = findViewById(R.id.login_button);
        testButton = findViewById(R.id.test_mode_button);
        usernameEditText = findViewById(R.id.username);

        userList = new ArrayList<>();
        userList.add(new User(644, 24, 144, 0, 0, 0 ,"Hello World \uD83D\uDC4F", 681));
        userList.add(new User(304 ,13 ,22 ,0 ,0 ,0 ,"a b c d e f g \uD83D\uDC4F", 515));
        userList.add(new User(341, 0, 3, 0, 0, 0, "", 278));

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                urlJsonArry = "https://www.instagram.com/"+ String.valueOf(usernameEditText.getText()) + "/?__a=1";
                makeJsonArrayRequest();

                if(user.getBiography() == null && user.getNumber_followers() == 0){
                    Toast.makeText(getApplicationContext(), "Instagram Server Error. Please Try Later! Default User is loading...", Toast.LENGTH_LONG).show();
                    user = new User(644, 24, 144, 0, 0, 0 ,"Hello World \uD83D\uDC4F", 681);
                }
                Intent i = new Intent(MainActivity.this, ppActivity.class);
                i.putExtra("USER", user);
                startActivity(i);
            }
        });

        testButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, ppActivity.class);
                i.putExtra("USER", userList.get(iter++));
                startActivity(i);
            }
        });
    }


    private void makeJsonArrayRequest() {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(urlJsonArry, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try{
                            JSONObject person =  response;

                            JSONObject graphqlObject = person.getJSONObject("graphql");
                            JSONObject userObject = graphqlObject.getJSONObject("user");

                            number_followers = userObject.getJSONObject("edge_followed_by").getDouble("count");
                            number_followees = userObject.getJSONObject("edge_follow").getDouble("count");
                            number_highlights = userObject.getDouble("highlight_reel_count");
                            number_media = userObject.getJSONObject("edge_owner_to_timeline_media").getDouble("count");
                            is_business = (double)Boolean.compare(userObject.getBoolean("is_business_account"), false);
                            is_professional = (double)Boolean.compare(userObject.getBoolean("is_professional_account"), false);
                            is_verified = (double)Boolean.compare(userObject.getBoolean("is_verified"), false);
                            biography = userObject.getString("biography");

                        }catch (JSONException e){
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                    }
                });
        AppController.getInstance().addToRequestQueue(jsonObjectRequest);
        user = new User(number_followees, number_highlights, number_media, is_business, is_professional, is_verified, biography, number_followers);
    }
}