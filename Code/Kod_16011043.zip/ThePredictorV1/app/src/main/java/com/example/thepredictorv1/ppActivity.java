package com.example.thepredictorv1;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import static com.example.thepredictorv1.MainActivity.modelComment;
import static com.example.thepredictorv1.MainActivity.modelLike;


public class ppActivity extends AppCompatActivity {
    private static final int IMAGE_PICK_CODE = 1000;
    private static final int PERMISSION_CODE = 1001;

    private Button predictButton;
    private ImageView mImageView;
    private EditText captionEditText;
    private TextView resultsTextView;
    private User user;
    private double number_words_biography;
    private double number_emojis_biography;
    private double number_words_caption;
    private double number_emojis_caption;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pp);

        predictButton = findViewById(R.id.choose_img_button);
        mImageView = findViewById(R.id.image_view);
        captionEditText = findViewById(R.id.caption_edit_text);
        resultsTextView = findViewById(R.id.results_prediction);

        mImageView.setImageResource(R.drawable.ic_baseline_image_24);
        user = (User) getIntent().getSerializableExtra("USER");

        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                    if(checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED){
                        String[] permissions = {Manifest.permission.READ_EXTERNAL_STORAGE};
                        requestPermissions(permissions, PERMISSION_CODE);
                    }
                    else{
                        pickImageFromGallery();
                    }
                }
                else{
                    pickImageFromGallery();
                }
            }
        });
        predictButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setCaption(captionEditText.getText().toString());

                number_words_biography = user.getWordCount(user.getBiography());
                number_emojis_biography = user.getEmojiCount(user.getBiography());
                number_words_caption = user.getWordCount(user.getCaption());
                number_emojis_caption = user.getEmojiCount(user.getCaption());

                double[] inputs = {  user.getNumber_followees(),
                        user.getNumber_highlights(),
                        user.getNumber_media(),
                        user.getIs_business(),
                        user.getIs_professional(),
                        user.getIs_verified(),
                        number_words_biography,
                        number_emojis_biography,
                        number_words_caption,
                        number_emojis_caption};

                double like_score = modelLike.score(inputs);
                double comment_score = modelComment.score(inputs);

                String res = "Your "+(float)(like_score*100)+ "% followers will like and "+(float)(comment_score*100)+"% comment this image."+" So, you will get " + (int)(like_score * user.getNumber_followers())+ " likes and "+ (int)(comment_score * user.getNumber_followers())+ " comments";
                resultsTextView.setText(res);
            }
        });
    }

    private void pickImageFromGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");
        startActivityForResult(intent, IMAGE_PICK_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case PERMISSION_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    pickImageFromGallery();
                } else {
                    Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
                }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == IMAGE_PICK_CODE) {
            mImageView.setImageURI(data.getData());
        }
    }
}
