package com.example.thepredictorv1;

import java.io.Serializable;

public class User implements Serializable {
    private double number_followees;
    private double number_highlights;
    private double number_media;
    private double is_business;
    private double is_professional;
    private double is_verified;
    private double number_followers;
    private String biography="";
    private String caption="";


    public User(double number_followees, double number_highlights, double number_media, double is_business, double is_professional, double is_verified, String biography, double number_followers) {
        this.number_followees = number_followees;
        this.number_highlights = number_highlights;
        this.number_media = number_media;
        this.is_business = is_business;
        this.is_professional = is_professional;
        this.is_verified = is_verified;
        this.biography = biography;
        this.number_followers = number_followers;
    }

    public double getEmojiCount(String str) {
        int emojiCount = 0;

        for (int i = 0; i < str.length(); i++) {
            int type = Character.getType(str.charAt(i));
            if (type == Character.SURROGATE || type == Character.OTHER_SYMBOL) {
                emojiCount++;
            }
        }

        return emojiCount/2;
    }
    public double getWordCount(String str){
        String[] wordArray = str.trim().split("\\s+");
        return (double) wordArray.length;
    }

    public double getNumber_followees() {
        return number_followees;
    }

    public double getNumber_highlights() {
        return number_highlights;
    }

    public double getNumber_media() {
        return number_media;
    }

    public double getIs_business() {
        return is_business;
    }

    public double getIs_professional() {
        return is_professional;
    }

    public double getIs_verified() {
        return is_verified;
    }

    public String getBiography() {
        return biography;
    }

    public String getCaption() {
        return caption;
    }

    public double getNumber_followers() {
        return number_followers;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }
}


